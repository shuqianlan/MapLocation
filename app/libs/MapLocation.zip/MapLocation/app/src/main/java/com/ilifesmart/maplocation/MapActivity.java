package com.ilifesmart.maplocation;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import com.baidu.mapapi.map.BaiduMap;
import com.baidu.mapapi.map.BaiduMapOptions;
import com.baidu.mapapi.map.MapStatusUpdate;
import com.baidu.mapapi.map.MapStatusUpdateFactory;
import com.baidu.mapapi.map.MapView;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class MapActivity extends AppCompatActivity {

	@BindView(R.id.BaiduMapView)
	MapView mBaiduMapView;

	private BaiduMap mBaiduMap;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_map);
		ButterKnife.bind(this);

		mBaiduMap = mBaiduMapView.getMap();

		mBaiduMap.setTrafficEnabled(true); // 开启交通图
		mBaiduMap.setCustomTrafficColor("FFFF0000", "AADD0000", "AA00DD00", "AA00FF00"); // 自定义路况图颜色 严重拥堵，拥堵，缓行，畅通

		MapStatusUpdate u = MapStatusUpdateFactory.zoomTo(13);
		mBaiduMap.animateMapStatus(u); // 地图状态刷新

		// 人群分布密度
		mBaiduMap.setBaiduHeatMapEnabled(true);
//		BaiduMapOptions options = new BaiduMapOptions();
//		options.mapType(BaiduMap.MAP_TYPE_SATELLITE);
//		options.compassEnabled(true);
	}

	@Override
	protected void onResume() {
		super.onResume();

		mBaiduMapView.onResume();
	}

	@Override
	protected void onPause() {
		super.onPause();

		mBaiduMapView.onPause();
	}

	@Override
	protected void onDestroy() {
		super.onDestroy();

		mBaiduMapView.onDestroy();
	}

	@OnClick(R.id.normal)
	public void onMapToNormal() {
		mBaiduMap.setMapType(BaiduMap.MAP_TYPE_NORMAL);
	}

	@OnClick(R.id.satelite)
	public void onMapToSatelite() {
		mBaiduMap.setMapType(BaiduMap.MAP_TYPE_SATELLITE);
	}

	@OnClick(R.id.empty)
	public void onMapToEmpty() {
		mBaiduMap.setMapType(BaiduMap.MAP_TYPE_NONE);
	}

	@OnClick(R.id.heat)
	public void onMapToHeat() {
		mBaiduMap.setBaiduHeatMapEnabled(!mBaiduMap.isBaiduHeatMapEnabled());
	}
}
